#!/usr/bin/env python3
"""
===============================================================================
REPRODUCIBLE DRUDE-LORENTZ DIELECTRIC FITTING PIPELINE
===============================================================================
Accompanying script for:
"Quantum Plasmonics in Nanostructured Optical Environments: Green-Tensor
Formalisms, Quantum Coherence, Entanglement, and Emerging Platforms"
Target Journal: Photonics and Nanostructures – Fundamentals and Applications

Authors: Priyanka & Ram Soorat (2026)

PURPOSE:
This script provides the complete reproducible fitting procedure for the
multi-oscillator Drude-Lorentz complex permittivity models of Gold (Au),
Silver (Ag), and Aluminum (Al) across optical and near-infrared wavelengths
(400 nm - 1000 nm), using non-linear bounded least squares.

RAW DATA SOURCES:
- Gold (Au) & Silver (Ag): Johnson & Christy, Phys. Rev. B 6, 4370 (1972)
- Aluminum (Al): Palik, Handbook of Optical Constants of Solids (1985)
===============================================================================
"""

import os
import sys
import numpy as np
import pandas as pd
from scipy.optimize import least_squares

# Physical constant
HC_EV_NM = 1239.84193  # photon energy in eV = hc / wavelength_in_nm

def drude_lorentz(w_ev, eps_inf, wp, gamma, lorentz_params):
    """
    Computes complex permittivity eps(omega) = eps_re + 1j * eps_im
    using the multi-oscillator Drude-Lorentz model:

        eps(w) = eps_inf - wp^2 / (w^2 + 1j * gamma * w)
                 + sum_m [ f_m * w_m^2 / (w_m^2 - w^2 - 1j * gamma_m * w) ]
    """
    drude = - (wp**2) / (w_ev**2 + 1j * gamma * w_ev)
    interband = 0.0 + 0.0j
    for f_m, w_m, g_m in lorentz_params:
        interband += (f_m * w_m**2) / (w_m**2 - w_ev**2 - 1j * g_m * w_ev)
    return eps_inf + drude + interband

def compute_metrics(y_exp, y_model):
    """Computes R^2 (coefficient of determination) and RMSE."""
    ss_res = np.sum((y_exp - y_model)**2)
    ss_tot = np.sum((y_exp - np.mean(y_exp))**2)
    r2 = 1.0 - (ss_res / ss_tot) if ss_tot > 0 else 1.0
    rmse = np.sqrt(np.mean((y_exp - y_model)**2))
    return r2, rmse

def fit_metal(w_ev, eps_exp_re, eps_exp_im, metal_name="Au", num_oscillators=2):
    """
    Executes bounded non-linear least-squares optimization via Trust Region Reflective (TRF).
    """
    eps_exp = eps_exp_re + 1j * eps_exp_im
    var_re = np.var(eps_exp_re) if np.var(eps_exp_re) > 0 else 1.0
    var_im = np.var(eps_exp_im) if np.var(eps_exp_im) > 0 else 1.0

    if metal_name == "Au":
        # 2 Lorentz oscillators (resolving 5d -> 6sp transitions at 2.4 eV and 3.4 eV)
        # Parameters: [eps_inf, wp, gamma, f1, w1, g1, f2, w2, g2]
        p0 = [5.97, 8.86, 0.066, 1.09, 2.68, 0.43, 0.72, 3.41, 1.25]
        lb = [1.0,  5.0,  0.010, 0.10, 2.00, 0.10, 0.10, 2.80, 0.20]
        ub = [12.0, 15.0, 0.300, 3.00, 3.20, 1.50, 3.00, 4.50, 2.50]

        def residual(p):
            model = drude_lorentz(w_ev, p[0], p[1], p[2], [(p[3], p[4], p[5]), (p[6], p[7], p[8])])
            res_re = (np.real(model) - eps_exp_re) / np.sqrt(var_re)
            res_im = (np.imag(model) - eps_exp_im) / np.sqrt(var_im)
            return np.concatenate([res_re, res_im])

    elif metal_name == "Ag":
        # 1 Lorentz oscillator (capturing 4d -> 5sp threshold near 4.0 eV)
        # Parameters: [eps_inf, wp, gamma, f1, w1, g1]
        p0 = [3.70, 9.20, 0.021, 0.85, 4.20, 0.25]
        lb = [1.0,  5.0,  0.005, 0.10, 3.50, 0.05]
        ub = [8.0,  14.0, 0.200, 2.50, 5.00, 1.00]

        def residual(p):
            model = drude_lorentz(w_ev, p[0], p[1], p[2], [(p[3], p[4], p[5])])
            res_re = (np.real(model) - eps_exp_re) / np.sqrt(var_re)
            res_im = (np.imag(model) - eps_exp_im) / np.sqrt(var_im)
            return np.concatenate([res_re, res_im])

    elif metal_name == "Al":
        # 1 Lorentz oscillator (capturing parallel-band absorption near 1.5 eV)
        # Parameters: [eps_inf, wp, gamma, f1, w1, g1]
        p0 = [1.00, 15.0, 0.600, 0.60, 1.50, 0.50]
        lb = [0.5,  10.0, 0.100, 0.10, 1.20, 0.10]
        ub = [5.0,  20.0, 1.500, 2.00, 2.00, 1.50]

        def residual(p):
            model = drude_lorentz(w_ev, p[0], p[1], p[2], [(p[3], p[4], p[5])])
            res_re = (np.real(model) - eps_exp_re) / np.sqrt(var_re)
            res_im = (np.imag(model) - eps_exp_im) / np.sqrt(var_im)
            return np.concatenate([res_re, res_im])

    # Run optimizer
    res = least_squares(residual, p0, bounds=(lb, ub), method='trf', ftol=1e-8, xtol=1e-8)
    p_opt = res.x

    # Evaluate model
    if num_oscillators == 2:
        fit = drude_lorentz(w_ev, p_opt[0], p_opt[1], p_opt[2], [(p_opt[3], p_opt[4], p_opt[5]), (p_opt[6], p_opt[7], p_opt[8])])
    else:
        fit = drude_lorentz(w_ev, p_opt[0], p_opt[1], p_opt[2], [(p_opt[3], p_opt[4], p_opt[5])])

    r2_re, rmse_re = compute_metrics(eps_exp_re, np.real(fit))
    r2_im, rmse_im = compute_metrics(eps_exp_im, np.imag(fit))
    joint_rmse = np.sqrt(0.5 * (rmse_re**2 + rmse_im**2))

    return {
        "metal": metal_name,
        "params": p_opt,
        "r2_re": r2_re,
        "r2_im": r2_im,
        "joint_rmse": joint_rmse,
        "success": res.success,
        "cost": res.cost,
        "fit": fit
    }

def main():
    print("=" * 75)
    print("REPRODUCIBLE DRUDE-LORENTZ DIELECTRIC FITTING PIPELINE")
    print("=" * 75)

    # Locate CSV
    csv_candidates = [
        "raw_dielectric_data_au_ag_al.csv",
        os.path.join("..", "raw_dielectric_data_au_ag_al.csv"),
        os.path.join(os.path.dirname(__file__), "raw_dielectric_data_au_ag_al.csv")
    ]
    csv_path = None
    for cand in csv_candidates:
        if os.path.exists(cand):
            csv_path = cand
            break

    if not csv_path:
        print("ERROR: raw_dielectric_data_au_ag_al.csv not found!")
        sys.exit(1)

    print(f"[*] Loading raw experimental data from: {csv_path}")
    df = pd.read_csv(csv_path, comment='#')
    wl_nm = df["wavelength_nm"].values
    w_ev = df["photon_energy_eV"].values

    print(f"[*] Calibrated spectral grid: {len(wl_nm)} points from {wl_nm[0]} nm to {wl_nm[-1]} nm ({w_ev[-1]:.2f} eV to {w_ev[0]:.2f} eV)\n")

    results = []
    # 1. Gold (Au)
    print("[-] Fitting Gold (Au) [Johnson & Christy 1972]...")
    res_au = fit_metal(w_ev, df["au_re"].values, df["au_im"].values, "Au", num_oscillators=2)
    results.append(res_au)
    p = res_au["params"]
    print(f"    eps_inf = {p[0]:.2f}, wp = {p[1]:.2f} eV, gamma = {p[2]:.3f} eV")
    print(f"    Oscillator 1: (f1={p[3]:.2f}, w1={p[4]:.2f} eV, g1={p[5]:.2f} eV)")
    print(f"    Oscillator 2: (f2={p[6]:.2f}, w2={p[7]:.2f} eV, g2={p[8]:.2f} eV)")
    print(f"    Goodness-of-fit: R^2(Re) = {res_au['r2_re']:.4f}, R^2(Im) = {res_au['r2_im']:.4f}, Joint RMSE = {res_au['joint_rmse']:.3f}\n")

    # 2. Silver (Ag)
    print("[-] Fitting Silver (Ag) [Johnson & Christy 1972]...")
    res_ag = fit_metal(w_ev, df["ag_re"].values, df["ag_im"].values, "Ag", num_oscillators=1)
    results.append(res_ag)
    p = res_ag["params"]
    print(f"    eps_inf = {p[0]:.2f}, wp = {p[1]:.2f} eV, gamma = {p[2]:.3f} eV")
    print(f"    Oscillator 1: (f1={p[3]:.2f}, w1={p[4]:.2f} eV, g1={p[5]:.2f} eV)")
    print(f"    Goodness-of-fit: R^2(Re) = {res_ag['r2_re']:.4f}, R^2(Im) = {res_ag['r2_im']:.4f}, Joint RMSE = {res_ag['joint_rmse']:.3f}\n")

    # 3. Aluminum (Al)
    print("[-] Fitting Aluminum (Al) [Palik 1985]...")
    res_al = fit_metal(w_ev, df["al_re"].values, df["al_im"].values, "Al", num_oscillators=1)
    results.append(res_al)
    p = res_al["params"]
    print(f"    eps_inf = {p[0]:.2f}, wp = {p[1]:.2f} eV, gamma = {p[2]:.3f} eV")
    print(f"    Oscillator 1: (f1={p[3]:.2f}, w1={p[4]:.2f} eV, g1={p[5]:.2f} eV)")
    print(f"    Goodness-of-fit: R^2(Re) = {res_al['r2_re']:.4f}, R^2(Im) = {res_al['r2_im']:.4f}, Joint RMSE = {res_al['joint_rmse']:.3f}\n")

    print("=" * 75)
    print("SUMMARY MATRIX OF FITTED DIELECTRIC PARAMETERS (TABLE S8 / SECTION S5):")
    print("=" * 75)
    print(f"{'Metal':<6} | {'eps_inf':<7} | {'wp (eV)':<8} | {'gamma':<8} | {'R2(Re)':<8} | {'R2(Im)':<8} | {'RMSE':<8}")
    print("-" * 75)
    for r in results:
        p = r["params"]
        print(f"{r['metal']:<6} | {p[0]:<7.2f} | {p[1]:<8.2f} | {p[2]:<8.3f} | {r['r2_re']:<8.4f} | {r['r2_im']:<8.4f} | {r['joint_rmse']:<8.3f}")
    print("=" * 75)
    print("[+] Complete fitting procedure successfully executed and verified.")

if __name__ == "__main__":
    main()
