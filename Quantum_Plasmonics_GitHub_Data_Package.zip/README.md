# quantum-plasmonics-prisma-data

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![PRISMA 2020](https://img.shields.io/badge/PRISMA-2020%20Compliant-blue.svg)](https://prisma-statement.org/)
[![Python 3.11+](https://img.shields.io/badge/Python-3.11%2B-green.svg)](https://www.python.org/)

**Official Open Data & Code Repository** for the review article:
> **"Quantum Plasmonics in Nanostructured Optical Environments: Green-Tensor Formalisms, Quantum Coherence, Entanglement, and Emerging Platforms"**  
> *Target Journal*: **Photonics and Nanostructures – Fundamentals and Applications** (Elsevier)  
> *Authors*: Priyanka & Ram Soorat  

---

## 📌 Repository Contents and File Manifest

This repository provides open access to all underlying data, PRISMA 2020 systematic search logs, quantitative extraction spreadsheets, master equation solvers, and reproduction scripts supporting the review:

| File / Directory | Description | Primary Output / Purpose |
|---|---|---|
| `prisma_search_log.csv` | Complete PRISMA 2020 systematic screening audit log across WoS, Scopus, and IEEE Xplore ($N=1,420 \to 890 \to 478 \to 248$). | Documents inclusion/exclusion counts at each stage. |
| `prisma_included_studies_master.csv` | Master quantitative dataset of primary included studies ($N=248$) classified into 5 thematic categories. | Tabulates physical observables, platforms, and author-assessed TRLs. |
| `qubit_concurrence_dynamics.py` | Standalone numerical solver for two-emitter collective Lindblad master equations driven by dyadic Green tensors. | Generates `concurrence_dynamics_benchmark.csv` and concurrence trajectory plots. |
| `concurrence_dynamics_benchmark.csv` | Time-resolved numerical trajectories of Wootters concurrence $\mathcal{C}(t)$, negativity $\mathcal{N}(t)$, and purity $\operatorname{Tr}(\rho^2)$. | Comparative numerical dataset evaluating Ohmic decay vs. chiral subradiant protection. |
| `raw_dielectric_data_au_ag_al.csv` | Raw empirical dielectric permittivity data for Au, Ag (Johnson & Christy 1972), and Al (Palik 1985) across 400--1000 nm. | Calibrated spectral input data for reproducible fitting procedure. |
| `fit_dielectric_drude_lorentz.py` | Standalone Python script for multi-oscillator Drude-Lorentz bounded least-squares fitting with objective, bounds, and RMSE. | Outputs fitted parameters, $R^2$ values, and RMSE across all three metals. |
| `plot_review_figures.py` | Python plotting pipeline for Drude-Lorentz multi-oscillator permittivity fits (Au, Ag, Al) and bibliometric trends. | Renders publication growth curves and material dispersion charts. |
| `references_200.bib` | Curated BibTeX database containing 246 indexed records with 100% verified digital object identifiers (DOIs). | Bibliographic source database supporting the review. |
| `figures/` | High-resolution publication figures in vector PDF, SVG, and raster PNG formats. | Ready-to-publish visual assets for manuscript and supplementary information. |
| `LICENSE` | Formal MIT open-source license. | Governs open re-use of all data, scripts, and logs. |
| `README.md` | Comprehensive execution guide and reproduction protocol. | Documents step-by-step shell execution commands. |

---

## 🔬 PRISMA 2020 Systematic Literature Review Summary

The literature survey follows Preferred Reporting Items for Systematic Reviews and Meta-Analyses (PRISMA 2020) guidelines:
- **Stage 1 (Identification)**: $N = 1,420$ records retrieved across Web of Science Core Collection ($680$), Scopus ($460$), and IEEE Xplore ($280$).
- **Stage 2 (Deduplication)**: $N = 530$ duplicate records removed ($1,420 - 530 = 890$).
- **Stage 3 (Title/Abstract Screening)**: $N = 412$ records excluded (classical macroscopic metamaterials, non-quantum SERS, non-photonic algorithms) ($890 - 412 = 478$).
- **Stage 4 (Full-Text Eligibility)**: $N = 230$ records excluded with stated reasons ($478 - 230 = 248$).
- **Stage 5 (Final Inclusion)**: **$N = 248$ primary peer-reviewed studies** (2010--2026) evaluated and synthesized into thematic matrices. Dual-author review verified screening consistency against predefined eligibility criteria.

### Five Thematic Category Breakdown:
1. **Green Tensors & Classical Electrodynamics**: $N = 58$ studies (23.4%)
2. **Photonic Entanglement & Open Quantum Systems**: $N = 64$ studies (25.8%)
3. **Chiral Nanophotonics & Metasurfaces**: $N = 42$ studies (16.9%)
4. **Non-Hermitian Plasmonics & Exceptional Points**: $N = 36$ studies (14.5%)
5. **AI Inverse Design & Nanofabrication Platforms**: $N = 48$ studies (19.4%)
$$\sum = 58 + 64 + 42 + 36 + 48 = 248 \quad (100.0\%)$$

> **Note on Database and Citations**: The PRISMA evidence dataset contains 248 eligible primary included studies. The repository also contains a BibTeX database (`references_200.bib`) of 246 indexed bibliographic records used to support the manuscript references (the final manuscript cites 151 core references, distinct from the 248-study systematic PRISMA corpus).

---

## 🚀 Step-by-Step Shell Execution Instructions

Follow these step-by-step shell commands to set up the execution environment, reproduce the numerical master equation solvers, and regenerate all analytical figures.

### Step 0: Clone Repository and Create Virtual Environment
```bash
# Clone the repository
git clone https://github.com/priyanka292c/quantum-plasmonics-prisma-data.git
cd quantum-plasmonics-prisma-data

# Option A: Using Conda (Recommended)
conda create -n qplasmonics python=3.11 -y
conda activate qplasmonics

# Option B: Using standard Python venv
python -m venv venv
# Linux / macOS:
source venv/bin/activate
# Windows PowerShell:
.\venv\Scripts\Activate.ps1

# Install core scientific dependencies
pip install --upgrade pip
pip install numpy>=1.24.0 scipy>=1.10.0 matplotlib>=3.7.0 pandas>=2.0.0 seaborn>=0.12.0
```

### Step 1: Verify and Inspect PRISMA Systematic Screening Data
```bash
# Inspect the PRISMA 2020 search and screening flow log
python -c "
import pandas as pd
df = pd.read_csv('prisma_search_log.csv')
print('=== PRISMA 2020 Search Log Summary ===')
print(df[['Phase', 'Database', 'Records_Found', 'Records_Excluded', 'Records_Remaining']])
"

# Inspect the master quantitative extraction dataset
python -c "
import pandas as pd
df = pd.read_csv('prisma_included_studies_master.csv')
print('=== Primary Included Studies Sample (First 5 Rows) ===')
print(df[['Study_ID', 'Year', 'Authors', 'Journal', 'Platform', 'Purcell_Factor_Fp', 'Author_Assessed_TRL']].head())
"
```

### Step 2: Run Two-Qubit Collective Lindblad Master Equation Solver
```bash
# Solves the 16x16 Liouvillian superoperator under dyadic Green-tensor cross-coupling:
#   - Conventional lossy Ohmic bath (beta_12 = 0.15) -> Entanglement Sudden Death
#   - Chiral / subradiant protected bath (beta_12 = 0.85) -> Subradiant coherence preservation
#   - Dark-state coupled bath (beta_12 = 0.96) -> Long-lived entanglement plateau
python qubit_concurrence_dynamics.py

# Expected Output:
#   - Saved benchmark numerical trajectories -> concurrence_dynamics_benchmark.csv
#   - Generated publication plot -> fig1_concurrence_computed.pdf
```

### Step 3: Run Reproducible Dielectric Permittivity Fitting Pipeline
```bash
# Fits multi-oscillator Drude-Lorentz models to empirical data from Johnson & Christy (1972) and Palik (1985)
# Minimizes weighted residual sum of squares using Trust Region Reflective (TRF) non-linear least squares
python fit_dielectric_drude_lorentz.py

# Expected Output:
#   - Prints fitted oscillator parameters (eps_inf, wp, gamma, f_m, w_m, gamma_m)
#   - Outputs goodness-of-fit metrics: R^2(Re), R^2(Im), and joint RMSE for Au, Ag, and Al
```

### Step 4: Reproduce Permittivity Fits and Bibliometric Publication Trends
```bash
# Fits Drude-Lorentz multi-oscillator parameters to Johnson & Christy (Au, Ag) and Palik (Al) data
# Generates quantitative publication volume growth curves (2010-2025 completed calendar years)
python plot_review_figures.py

# Expected Output:
#   - Saved permittivity comparison -> figures/figS2a_au_permittivity.pdf
#   - Saved publication trend growth -> figures/figS3_publication_trends.pdf
```

---

## 📄 License & Citation

All data tables and scripts in this repository are released under the [MIT License](LICENSE).  
If you utilize this dataset, master equation solver, or extraction tables, please cite:

```bibtex
@article{priyanka2026quantum,
  title   = {Quantum Plasmonics in Nanostructured Optical Environments: Green-Tensor Formalisms, Quantum Coherence, Entanglement, and Emerging Platforms},
  author  = {Priyanka and Soorat, Ram},
  journal = {Photonics and Nanostructures -- Fundamentals and Applications},
  year    = {2026},
  note    = {Under Review}
}
```
