# quantum-plasmonics-prisma-data

**Open Data Repository & Python Execution Scripts** for the Review Article:
> *"Quantum Plasmonic Materials and Photonic Entanglement: A Comprehensive Review"*

---

## 📌 Repository Contents

1. **`prisma_search_log.csv`**: Complete PRISMA 2020 systematic search log documenting initial query records ($N=1,420$), deduplication ($N=530$), title/abstract screening ($N=412$ excluded), full-text eligibility assessment ($N=230$ excluded), and final peer-reviewed study inclusion ($N=248$). Inter-reviewer screening reliability achieved Cohen's $\kappa = 0.88$.
2. **`prisma_included_studies_master.csv`**: Master quantitative dataset of all $N=248$ screened primary studies categorized by material platform, emitter type, Purcell factor $F_\mathrm{P}$, vacuum Rabi splitting $\hbar\Omega_\mathrm{R}$, concurrence $\mathcal{C}$, cross-coherence $\beta_{12}$, and Technology Readiness Level (TRL).
3. **`plot_review_figures.py`**: Execution script to reproduce figures, Drude-Lorentz permittivity fits (Au, Ag, Al), CAGR publication growth regressions ($18.0\%$), and PRISMA flowcharts.
4. **`figures/`**: High-resolution vector PDF, PNG, and SVG figure files for the main review and supplementary information.

---

## 🚀 Reproduction Instructions

To run the Python scripts and regenerate all analytical figures:

```bash
# Clone repository
git clone https://github.com/priyanka292c/quantum-plasmonics-prisma-data.git
cd quantum-plasmonics-prisma-data

# Install required dependencies
pip install numpy scipy matplotlib pandas seaborn

# Execute figure generation
python plot_review_figures.py
```

---

## 📄 License
This repository is released under the [MIT License](LICENSE).
