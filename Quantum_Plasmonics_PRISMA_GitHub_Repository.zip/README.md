# quantum-plasmonics-prisma-data

**Open Data Repository & Python Execution Scripts** for the Topical Review:
> *"Quantum Plasmonics and Photonic Entanglement: Formalisms, Materials, and a Technology Roadmap"*

---

## 📌 Repository Contents

1. **`prisma_search_log.csv`**: Complete PRISMA 2020 systematic search log documenting initial query records ($N=1,420$), deduplication ($N=530$), title/abstract screening ($N=412$ excluded), full-text eligibility assessment ($N=230$ excluded), and final peer-reviewed primary study inclusion ($N=248$). Inter-reviewer screening reliability achieved Cohen's $\kappa = 0.88$.
2. **`prisma_included_studies_master.csv`**: Master quantitative dataset of screened primary studies categorized by material platform, emitter type, Purcell factor $F_\mathrm{P}$, vacuum Rabi splitting $\hbar\Omega_\mathrm{R}$, concurrence $\mathcal{C}$, cross-coherence $\beta_{12}$, and Technology Readiness Level (TRL).
3. **`plot_review_figures.py`**: Python script to reproduce analytical review figures, Drude-Lorentz permittivity fits (Au, Ag, Al), bibliometric publication growth regressions ($N_{2010} = 18 \to N_{2025} = 200$, $r = 0.160\text{ yr}^{-1}$, $R^2 = 0.992$, $\mathrm{CAGR} = 17.4\%$), and PRISMA flowcharts.
4. **`qubit_concurrence_dynamics.py`**: Numerical solver for non-Markovian two-qubit concurrence and entanglement dynamics mediated by dyadic Green tensors.
5. **`concurrence_dynamics_benchmark.csv`**: Numerical benchmark trajectory data for two-qubit concurrence and state fidelity.
6. **`figures/`**: High-resolution vector PDF, PNG, and SVG figure files for the review and supplementary information.

---

## 🚀 Reproduction Instructions

To run the Python scripts and regenerate all analytical figures:

```bash
# Clone repository
git clone https://github.com/priyanka292c/quantum-plasmonics-prisma-data.git
cd quantum-plasmonics-prisma-data

# Install required dependencies
pip install numpy scipy matplotlib pandas seaborn

# Execute figure generation
python plot_review_figures.py

# Execute concurrence dynamics solver
python qubit_concurrence_dynamics.py
```

---

## 📄 License
This repository is released under the [MIT License](LICENSE).

